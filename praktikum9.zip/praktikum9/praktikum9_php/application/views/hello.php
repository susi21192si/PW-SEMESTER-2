<h1>Selamat Datang!!!<?=$nama?></h1>
<h3>Di <?php echo $title?></h3>
