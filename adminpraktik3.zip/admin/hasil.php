<?php
 include_once 'header.php';
?>

<h1>Welcome Home !!! </h1>

<?php
 require_once 'footer.php';
?>