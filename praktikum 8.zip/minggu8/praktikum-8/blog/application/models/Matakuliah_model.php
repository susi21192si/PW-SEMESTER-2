<?php

//buat Class
class Matakuliah_model extends CI_Model {
    //buat struktur data property/variabel
    public $nama, $sks, $kode;
}
?>