<?php

//buat Class
class Dosen_model extends CI_Model {
    //buat struktur data property/variabel
    public $id, $nama, $nidn, $gender, $tmp_lahir, $tgl_lahir, $pendidikan;
}
?>