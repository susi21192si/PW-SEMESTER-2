<footer>
    <p>Created by <a href="http://nurulfikri.ac.id">Pusinfo NF &copy;2017</a>
</footer>
</body>
</html>